function B=in_box(x_start,x_end,y_start,y_end,z_start,z_end,A,lattice,lamda_delta_z)
j=1;
for i=1:size(A,2)
    if (A(1,i)<=x_end && A(2,i)<=y_end && A(3,i)<=z_end && A(1,i)>=x_start && A(2,i)>=y_start && A(3,i)>=z_start)
        B(:,j)=A(:,i);j=j+1;
    end
end
B(3,:)=B(3,:)+lamda_delta_z*lattice*ones(1,size(A,3));
%subplot(2,2,2);scatter3(pos_new(1,:),pos_new(2,:),pos_new(3,:),3.0,'MarkerFaceColor',[0 .75 .75]);axis equal;axis on;xlabel('x');ylabel('y');zlabel('z');
end
