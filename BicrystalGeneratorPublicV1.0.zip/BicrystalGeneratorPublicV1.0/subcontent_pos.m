function [pos_start,pos_end]=subcontent_pos(content,subcontent)
    num=['0','1','2','3','4','5','6','7','8','9','.','-'];
    n=length(subcontent);
    i=1;
    while (strcmp(content(i:i+n-1),subcontent)~=1)
        i=i+1;
    end
    pos_start=i+n;
    pos_end=pos_start;
    
    while(pos_end<=length(content) && ismember(content(pos_end),num)==1)
        pos_end=pos_end+1;
    end
    pos_end=pos_end-1;
end