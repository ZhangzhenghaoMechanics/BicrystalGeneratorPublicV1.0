function varargout = GUI_GB(varargin)
% GUI_GB MATLAB code for GUI_GB.fig
%      GUI_GB, by itself, creates a new GUI_GB or raises the existing
%      singleton*.
%
%      H = GUI_GB returns the handle to a new GUI_GB or the handle to
%      the existing singleton*.
%
%      GUI_GB('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI_GB.M with the given input arguments.
%
%      GUI_GB('Property','Value',...) creates a new GUI_GB or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GUI_GB_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GUI_GB_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GUI_GB

% Last Modified by GUIDE v2.5 30-Jul-2021 18:02:27

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GUI_GB_OpeningFcn, ...
                   'gui_OutputFcn',  @GUI_GB_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GUI_GB is made visible.
function GUI_GB_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUI_GB (see VARARGIN)

% Choose default command line output for GUI_GB
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes GUI_GB wait for user response (see UIRESUME)
% uiwait(handles.figure1);
im1 = imread('parameter.png');
axes(handles.axes1);
imshow(im1);
im2 = imread('in_modify.png');
axes(handles.axes2);
imshow(im2);

% --- Outputs from this function are returned to the command line.
function varargout = GUI_GB_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function lattice_Callback(hObject, eventdata, handles)
% hObject    handle to lattice (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of lattice as text
%        str2double(get(hObject,'String')) returns contents of lattice as a double


% --- Executes during object creation, after setting all properties.
function lattice_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lattice (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function metal_type_Callback(hObject, eventdata, handles)
% hObject    handle to metal_type (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of metal_type as text
%        str2double(get(hObject,'String')) returns contents of metal_type as a double


% --- Executes during object creation, after setting all properties.
function metal_type_CreateFcn(hObject, eventdata, handles)
% hObject    handle to metal_type (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function misorientation_Callback(hObject, eventdata, handles)
% hObject    handle to misorientation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of misorientation as text
%        str2double(get(hObject,'String')) returns contents of misorientation as a double


% --- Executes during object creation, after setting all properties.
function misorientation_CreateFcn(hObject, eventdata, handles)
% hObject    handle to misorientation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function x_dup_Callback(hObject, eventdata, handles)
% hObject    handle to x_dup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of x_dup as text
%        str2double(get(hObject,'String')) returns contents of x_dup as a double


% --- Executes during object creation, after setting all properties.
function x_dup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to x_dup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function y_dup_Callback(hObject, eventdata, handles)
% hObject    handle to y_dup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of y_dup as text
%        str2double(get(hObject,'String')) returns contents of y_dup as a double


% --- Executes during object creation, after setting all properties.
function y_dup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to y_dup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function z_dup_Callback(hObject, eventdata, handles)
% hObject    handle to z_dup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of z_dup as text
%        str2double(get(hObject,'String')) returns contents of z_dup as a double


% --- Executes during object creation, after setting all properties.
function z_dup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to z_dup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function lamda_delta_y_Callback(hObject, eventdata, handles)
% hObject    handle to lamda_delta_y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of lamda_delta_y as text
%        str2double(get(hObject,'String')) returns contents of lamda_delta_y as a double


% --- Executes during object creation, after setting all properties.
function lamda_delta_y_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lamda_delta_y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function lamda_delta_z_Callback(hObject, eventdata, handles)
% hObject    handle to lamda_delta_z (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of lamda_delta_z as text
%        str2double(get(hObject,'String')) returns contents of lamda_delta_z as a double


% --- Executes during object creation, after setting all properties.
function lamda_delta_z_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lamda_delta_z (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

lattice=str2num(get(handles.lattice,'string'));
metal_type=(get(handles.metal_type,'string'));
misorientation=str2num(get(handles.misorientation,'string'));
x_dup=str2num(get(handles.x_dup,'string'));
y_dup=str2num(get(handles.y_dup,'string'));
z_dup=str2num(get(handles.z_dup,'string'));
lamda_delta_y=str2num(get(handles.lamda_delta_y,'string'));
lamda_delta_z=str2num(get(handles.lamda_delta_z,'string'));

niu_delta_y=str2num(get(handles.niu_delta_y,'string'));
niu_delta_z=str2num(get(handles.niu_delta_z,'string'));

theta=misorientation/2;
e=z_dup/y_dup;

x_range=x_dup*lattice;
%global theta n_x n_y n_z lattice;
%z>=y的情况
y_range=y_dup*lattice/(e*cosd(theta)+sind(theta))-3.52*2;
z_range=e*y_range;
z_mirror=z_range/2;


%global y_range z_range
for var_lamda_delta_z=0:niu_delta_z*lamda_delta_z:lamda_delta_z
%var_lamda_delta_z=lamda_delta_z;
    for var_lamda_delta_y=0:niu_delta_y*lamda_delta_y:lamda_delta_y     
        workpath=pwd;
        
        filename=['theta_',num2str(theta),'_ldy_',num2str(var_lamda_delta_y),'_ldz_',num2str(var_lamda_delta_z)];
        A1=ini_lattice(lattice,theta,x_dup,1.5*y_dup,1.5*z_dup);B1=in_box(0,x_range,-y_range/2,y_range/2,-z_mirror,0,A1,lattice,0);
        A2=ini_lattice(lattice,-theta,x_dup,1.5*y_dup,1.5*z_dup);
        A2=A2+[0*ones(1,size(A2,2));var_lamda_delta_y*lattice*ones(1,size(A2,2));0*ones(1,size(A2,2))];%y方向错动偏移
        B2=in_box(0,x_range,-y_range/2,y_range/2,0,z_mirror,A2,lattice,var_lamda_delta_z);
                
        C=[B1,B2];

        write_lmp(C,filename,lattice,0.5,0.5,0.5);
        figure(1);
        scatter3(C(1,:),C(2,:),C(3,:),150/sqrt(x_dup*y_dup),'MarkerEdgeColor',[1.0  0.5  0.2],'MarkerFaceColor',[1.0  0.8  0.2]);axis equal;axis on;xlabel('x');ylabel('y');zlabel('z');view(108,9);grid off;axis off;view(90,0);title('Cu double crystal');
        xlabel('x');ylabel('y');zlabel('z');

    end
end

function pushbutton1_CreateFcn(hObject, eventdata, handles)



function niu_delta_y_Callback(hObject, eventdata, handles)
% hObject    handle to niu_delta_y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of niu_delta_y as text
%        str2double(get(hObject,'String')) returns contents of niu_delta_y as a double


% --- Executes during object creation, after setting all properties.
function niu_delta_y_CreateFcn(hObject, eventdata, handles)
% hObject    handle to niu_delta_y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function niu_delta_z_Callback(hObject, eventdata, handles)
% hObject    handle to niu_delta_z (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of niu_delta_z as text
%        str2double(get(hObject,'String')) returns contents of niu_delta_z as a double


% --- Executes during object creation, after setting all properties.
function niu_delta_z_CreateFcn(hObject, eventdata, handles)
% hObject    handle to niu_delta_z (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sentence1_before_Callback(hObject, eventdata, handles)
% hObject    handle to sentence1_before (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sentence1_before as text
%        str2double(get(hObject,'String')) returns contents of sentence1_before as a double


% --- Executes during object creation, after setting all properties.
function sentence1_before_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sentence1_before (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function in_line_Callback(hObject, eventdata, handles)
% hObject    handle to in_line (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of in_line as text
%        str2double(get(hObject,'String')) returns contents of in_line as a double


% --- Executes during object creation, after setting all properties.
function in_line_CreateFcn(hObject, eventdata, handles)
% hObject    handle to in_line (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double


% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit16_Callback(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit16 as text
%        str2double(get(hObject,'String')) returns contents of edit16 as a double


% --- Executes during object creation, after setting all properties.
function edit16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2



function edit18_Callback(hObject, eventdata, handles)
% hObject    handle to edit18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit18 as text
%        str2double(get(hObject,'String')) returns contents of edit18 as a double


% --- Executes during object creation, after setting all properties.
function edit18_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function in_content_aft_matrix_Callback(hObject, eventdata, handles)
% hObject    handle to in_content_aft_matrix (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of in_content_aft_matrix as text
%        str2double(get(hObject,'String')) returns contents of in_content_aft_matrix as a double


% --- Executes during object creation, after setting all properties.
function in_content_aft_matrix_CreateFcn(hObject, eventdata, handles)
% hObject    handle to in_content_aft_matrix (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit20_Callback(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit20 as text
%        str2double(get(hObject,'String')) returns contents of edit20 as a double


% --- Executes during object creation, after setting all properties.
function edit20_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function character_content1_Callback(hObject, eventdata, handles)
% hObject    handle to character_content1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of character_content1 as text
%        str2double(get(hObject,'String')) returns contents of character_content1 as a double


% --- Executes during object creation, after setting all properties.
function character_content1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to character_content1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function num_start1_Callback(hObject, eventdata, handles)
% hObject    handle to num_start1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of num_start1 as text
%        str2double(get(hObject,'String')) returns contents of num_start1 as a double


% --- Executes during object creation, after setting all properties.
function num_start1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to num_start1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function num_add1_Callback(hObject, eventdata, handles)
% hObject    handle to num_add1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of num_add1 as text
%        str2double(get(hObject,'String')) returns contents of num_add1 as a double


% --- Executes during object creation, after setting all properties.
function num_add1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to num_add1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function num_end1_Callback(hObject, eventdata, handles)
% hObject    handle to num_end1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of num_end1 as text
%        str2double(get(hObject,'String')) returns contents of num_end1 as a double


% --- Executes during object creation, after setting all properties.
function num_end1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to num_end1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





function in_filename_ini_Callback(hObject, eventdata, handles)
% hObject    handle to in_filename_ini (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of in_filename_ini as text
%        str2double(get(hObject,'String')) returns contents of in_filename_ini as a double


% --- Executes during object creation, after setting all properties.
function in_filename_ini_CreateFcn(hObject, eventdata, handles)
% hObject    handle to in_filename_ini (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end






% --- Executes during object creation, after setting all properties.
function in_read1_button_CreateFcn(hObject, eventdata, handles)
% hObject    handle to in_read1_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% --- Executes on button press in in_read1_button.
function in_read1_button_Callback(hObject, eventdata, handles)
% hObject    handle to in_read1_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

in_filename_ini=get(handles.in_filename_ini,'string');
in_line=str2num(get(handles.in_line,'string'));

in_content_ini=in_read(in_filename_ini,in_line);

set(handles.sentence1_before,'string',in_content_ini);





% --- Executes during object creation, after setting all properties.
function in_gen1_button_CreateFcn(hObject, eventdata, handles)
% hObject    handle to in_gen1_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% --- Executes on button press in in_gen1_button.
function in_gen1_button_Callback(hObject, eventdata, handles)
% hObject    handle to in_gen1_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

in_filename_ini=get(handles.in_filename_ini,'string');
in_line=str2num(get(handles.in_line,'string'));
in_content_ini=in_read(in_filename_ini,in_line);

character_content1=get(handles.character_content1,'string');
num_start1=str2num(get(handles.num_start1,'string'));
num_add1=str2num(get(handles.num_add1,'string'));
num_end1=str2num(get(handles.num_end1,'string'));

i=1;
for num1=num_start1:num_add1:num_end1
    i=i+1;
    in_content_aft_matrix(i,:)=in_content_ini;
    [pos_start1,pos_end1]=subcontent_pos(in_content_ini,character_content1);
    temp=[in_content_aft_matrix(i,1:pos_start1-1),num2str(num1),in_content_aft_matrix(i,pos_end1+1:end)];
    in_content_final_matrix(i,1:length(temp))=temp;
end

set(handles.in_content_aft_matrix,'string',in_content_final_matrix);

i=1;

%for i=1:size(in_content_final_matrix,1)
%    text_modify(in_filename_ini,[num2str(i),'.in'],in_content_final_matrix(i,:),in_line);
%end


% --- Executes during object creation, after setting all properties.
function in_gen1_infile_button_CreateFcn(hObject, eventdata, handles)
% hObject    handle to in_gen1_infile_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in in_gen1_infile_button.
function in_gen1_infile_button_Callback(hObject, eventdata, handles)
% hObject    handle to in_gen1_infile_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


in_filename_ini=get(handles.in_filename_ini,'string');
in_line=str2num(get(handles.in_line,'string'));
in_content_ini=in_read(in_filename_ini,in_line);

character_content1=get(handles.character_content1,'string');
num_start1=str2num(get(handles.num_start1,'string'));
num_add1=str2num(get(handles.num_add1,'string'));
num_end1=str2num(get(handles.num_end1,'string'));

i=1;
for num1=num_start1:num_add1:num_end1
    
    in_content_aft_matrix(i,:)=in_content_ini;
    [pos_start1,pos_end1]=subcontent_pos(in_content_ini,character_content1);
    temp=[in_content_aft_matrix(i,1:pos_start1-1),num2str(num1),in_content_aft_matrix(i,pos_end1+1:end)];
    in_content_final_matrix(i,1:length(temp))=temp;
    text_modify(in_filename_ini,[num2str(i),'.in'],temp,in_line);
    i=i+1;
end



