lattice=3.606;theta=20;x_dup=20;y_dup=20;z_dup=20;
A=ini_lattice(lattice,theta,x_dup,y_dup,z_dup);

a=[1;-1;2]/sqrt(6);
b=[-1;1;1]/sqrt(3);
c=[1;1;0];sqrt(2);
Rotate0=[a,b,c];
A=Rotate0*A;
A=in_box(0,20,-20,20,-20,20,A,lattice,0);
scatter3(A(1,:),A(2,:),A(3,:),20,'filled');