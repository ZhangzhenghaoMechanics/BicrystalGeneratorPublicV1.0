function pos=ini_lattice(lattice,theta,n_x,n_y,n_z)
%%生成原子坐标%%
%x范围：0~n_x*a,y范围：-n_y/2*a~n_y/2*a,z范围：-n_z/2*a~n_z/2*a,
%a=3.52;
%theta=0;
%n_x=10;n_y=20;n_z=20;
pos_sc=[];pos_fcc1=[];pos_fcc2=[];pos_fcc3=[];
pos_fcc_x_boundary=[];pos_fcc_y_boundary=[];pos_fcc_z_boundary=[];
Rotate0=[];
Rotate=[1,0,0;0,cosd(theta),sind(theta);0,-sind(theta),cosd(theta)]';%改变初始晶向后再旋转改变misorientation

for x=0:lattice:n_x*lattice
    for y=-n_y/2*lattice:lattice:n_y/2*lattice
        for z=-n_z/2*lattice:lattice:n_z/2*lattice
            pos_sc=[pos_sc,[x;y;z]];
        end
    end
end

%fcc1，在[100]面上
for x=0+0  :lattice:  n_x*lattice
    for y=-n_y/2*lattice+lattice/2  :lattice:  n_y/2*lattice
        for z=-n_z/2*lattice+lattice/2  :lattice:  n_z/2*lattice
            pos_fcc1=[pos_fcc1,[x;y;z]];
        end
    end
end

%%fcc2,在[010]面上
for x=0+lattice/2  :lattice:  n_x*lattice
    for y=-n_y/2*lattice+0  :lattice:  n_y/2*lattice
        for z=-n_z/2*lattice+lattice/2  :lattice:  n_z/2*lattice
            pos_fcc2=[pos_fcc2,[x;y;z]];
        end
    end
end
%%fcc3，在[001]面上
for x=0+lattice/2  :lattice:  n_x*lattice
    for y=-n_y/2*lattice+lattice/2  :lattice:  n_y/2*lattice
        for z=-n_z/2*lattice+0  :lattice:  n_z/2*lattice
            pos_fcc3=[pos_fcc3,[x;y;z]];
        end
    end
end

pos=[pos_sc,pos_fcc1,pos_fcc2,pos_fcc3];%至此得到FCC类型所有原子坐标

row=[find(pos(1,:)==n_x*lattice),find(pos(2,:)==n_y/2*lattice),find(pos(3,:)==n_z/2*lattice)];
pos(:,row)=[];
pos=Rotate*pos;
pos=roundn(pos,-5);pos=unique(pos','rows')';
%figure(1);
%subplot(2,2,1);
%scatter3(pos_sc(1,:),pos_sc(2,:),pos_sc(3,:),150/sqrt(n_y*n_z),'MarkerEdgeColor',[1.0  0.5  0.2],'MarkerFaceColor',[1.0  0.8  0.2]);axis equal;axis on;xlabel('x');ylabel('y');zlabel('z');view(108,9);grid off;axis off;view(90,0);title('Cu single crystal');
%xlabel('x');ylabel('y');zlabel('z');
%%subplot(2,2,2);
%%scatter3(pos(1,:),pos(2,:),pos(3,:),20.0,'MarkerFaceColor',[0 .75 .75]);axis equal;axis on;xlabel('x');ylabel('y');zlabel('z');view(108,9);grid off;axis off;view(90,0);
%%xlabel('x');ylabel('y');zlabel('z');
end