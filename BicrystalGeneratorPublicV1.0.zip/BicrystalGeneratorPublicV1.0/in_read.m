function content=in_read(in_filename_ini,line)

    fileID = fopen(in_filename_ini,'r+');
    i=1;
    while (i<=line)
        i=i+1;
        content=fgetl(fileID);
    end

end